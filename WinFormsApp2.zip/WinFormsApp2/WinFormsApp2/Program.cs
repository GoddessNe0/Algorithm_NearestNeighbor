namespace WinFormsApp2
{
    internal static class Program
    {
        private static Form1 form1 = new Form1();
        private static Form2 form2 = new Form2();
        private static Form3 form3 = new Form3(form1);
        private static Form4 form4 = new Form4();

        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            form3.Show();
            Application.Run(new Form1());


        }
    }
}