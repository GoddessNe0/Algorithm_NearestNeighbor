﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp2
{
    public partial class Form3 : Form
    {
        private bool is_aut = false;
        private Form1 parent;
        public Form3(Form1 parent)
        {
            InitializeComponent();
            this.parent = parent;
        }

        private void Form3_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (!is_aut)
            {
                Application.Exit();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string login = "123";
            string password = "456";

            string log_text = textBox1.Text;
            string pas_text = textBox2.Text;

            if (login == log_text && password == pas_text)
            {
                parent.UserAut();
                Hide();
                is_aut = true;
                this.Close();
            }
            else
            {
                MessageBox.Show("Пользователь с таким паролем не найден! Перепроверьте правильность и попробуйте снова", "Ошибка входа", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


    }
}
